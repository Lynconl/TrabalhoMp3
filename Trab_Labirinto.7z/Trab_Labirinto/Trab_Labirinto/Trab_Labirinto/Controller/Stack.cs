﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trab_Labirinto.Model;

namespace Trab_Labirinto.Controller
{
    class Stack
    {
        private Size begin = null, end = null;

        internal Size Begin { get => begin; set => begin = value; }
        internal Size End { get => end; set => end = value; }


        public void Push(string patch)
        {
            Size newSize = new Size(patch);
            newSize.Patch = patch;

            if (Begin == null)
            {
                Begin = newSize;
                End = newSize;

            }

            else
            {
                End.Next = newSize;
            }
            End = newSize;
        }

        public void Pop()   
        {
            if (Begin == null)
            {

                return;
            }
            if (Begin.Next == null)
            {
                Begin = null;
            }
            else
            {
                Size last = Begin.Next;
                Size penultimate = Begin;
                while (last.Next != null)
                {
                    penultimate = last;
                    last = last.Next;
                }
                penultimate.Next = null;
                end = penultimate;
            }
        }
    }


}
