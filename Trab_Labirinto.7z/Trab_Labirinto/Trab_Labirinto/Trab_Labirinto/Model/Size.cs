﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trab_Labirinto.Model
{
    class Size
    {
        private string patch;
        private Size next;

        public Size(string patch)
        {
            patch = Patch;
            Next = null;
        }

        public string Patch { get => patch; set => patch = value; }
        internal Size Next { get => next; set => next = value; }
    }
}
