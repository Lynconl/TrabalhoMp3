﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Trab_Labirinto
{
    public partial class FormPrincipal : Form
    {
        Graphics Gra;
        Rectangle Preto;
        string curDir = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory.ToString());
        int X, Y, PX;
        bool Pintar=false;

        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void Parte1Labirinto()
        {
            Gra = this.CreateGraphics();

            X = Convert.ToInt16(comboBoxXY.Text);
            Y = Convert.ToInt16(comboBoxXY.Text);
            PX = Convert.ToInt16(comboBoxPX.Text);

            for (int i = PX*2; i <= X; i += PX)
            {
                Preto.Height = PX;
                Preto.Width = PX;
                Preto.X = i;
                Preto.Y = PX;

                if (i == X)
                {
                    Preto.Height = PX;
                    Preto.Width = PX;
                    Preto.X = i;
                    int Vert = PX;
                    while (Vert < i)
                    {
                        Preto.Y = Vert;
                        Vert += PX;
                        if (Vert == (Y - PX) | Vert == Y)
                        {
                            Gra.FillRectangle(Brushes.Red, Preto);
                        }
                        else
                        {
                            Gra.FillRectangle(Brushes.Black, Preto);
                        }
                    }

                    int X = Convert.ToInt16(comboBoxXY.Text);
                    while (X >= PX)
                    {
                        Preto.Y = Y;
                        Preto.X = X;
                        Gra.FillRectangle(Brushes.Black, Preto);
                        X -= PX;
                    }

                    while (Y >= PX)
                    {
                        Preto.Y = Y;
                        Preto.X = X+PX;
                        Y -= PX;
                        Gra.FillRectangle(Brushes.Black, Preto);
                        
                    }
                }
                if (i == (PX * 2) | i == (PX * 3))
                {
                    Gra.FillRectangle(Brushes.Red, Preto);
                }
                else
                {
                    Gra.FillRectangle(Brushes.Black, Preto);
                }

            }
        }

        private void CriarArquivo()
        {            
            StreamWriter Criar = new StreamWriter(curDir + "\\Labirinto.txt");
            int Sorteio, i=0;
            Random Rd = new Random();

            string T="";
            while(i <= (Convert.ToInt16(comboBoxXY.Text)*2)/Convert.ToInt16(PX))
            {                
                Sorteio = Rd.Next(0, 2); //0 == Branco | 1 == Preto
                T += Sorteio.ToString() + "";                
                i++;
                if (i == (Convert.ToInt16(comboBoxXY.Text)/ Convert.ToInt16(PX)))
                {
                    Criar.WriteLine(T + "\n");
                    T = "";                    
                }                
            }
            Criar.Close();
        }

        private void LerArquivo()
        {
            StreamReader Leitor = new StreamReader(curDir + "\\Labirinto.txt");
            Leitor.ReadLine();
            int posicaoX = PX * 3;
            int posicaoY = PX * 3;
            while (Leitor != null)
            {
                String Numeros = Leitor.ToString();
                var chars = Numeros.ToCharArray();
                for(int i=0; i < chars.Length; i++)
                {
                    PX += PX;
                    posicaoX += PX;
                    if (chars[i] == 0)
                    {
                        Preto.Height = PX;
                        Preto.Width = PX;
                        Preto.X = posicaoX;
                        Preto.Y = posicaoY;
                        Gra.FillRectangle(Brushes.Green, Preto);

                    }else
                    if (chars[i] == 1)
                    {
                        Preto.Height = PX;
                        Preto.Width = PX;
                        Preto.X = posicaoX;
                        Preto.Y = posicaoY;
                        Gra.FillRectangle(Brushes.Black, Preto);
                    }
                }
                posicaoY += PX;
                
            }
        }

        private void bttnCriarLab_Click(object sender, EventArgs e)
        {            
            Pintar = true;
            Refresh();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (Pintar)
            {
                Parte1Labirinto();
                CriarArquivo();
                Pintar = false;
            }                       
        }

        private void pictureBoxSair_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }

    }
}
