﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Trab_Labirinto
{
    public partial class Form1 : Form
    {
        Graphics Gra;
        Rectangle Preto;
        public Form1()
        {
            InitializeComponent();
        }

        private void Parte1Labirinto()
        {
            Gra = this.CreateGraphics();
            int Y = 10;

            for (int i = 10; i <= 600; i += 10)
            {
                Preto.Height = 10;
                Preto.Width = 10;
                Preto.X = i;
                Preto.Y = Y;

                if (i == 600)
                {
                    Preto.Height = 10;
                    Preto.Width = 10;
                    Preto.X = 600;

                    while (Y < 600)
                    {
                        Preto.Y = Y;
                        Y += 10;
                        if (Y == 590 | Y == 600)
                        {
                            Gra.FillRectangle(Brushes.Red, Preto);
                        }
                        else
                        {
                            Gra.FillRectangle(Brushes.Black, Preto);
                        }

                    }

                    int X = 600;
                    while (X >= 20)
                    {

                        Preto.Y = Y;
                        Preto.X = X;
                        Gra.FillRectangle(Brushes.Black, Preto);
                        X -= 10;
                    }

                    while (Y >= 10)
                    {
                        Preto.Y = Y;
                        Preto.X = X;
                        Gra.FillRectangle(Brushes.Black, Preto);
                        Y -= 10;
                    }
                }
                if (i == 20 | i == 30)
                {
                    Gra.FillRectangle(Brushes.Red, Preto);
                }
                else
                {
                    Gra.FillRectangle(Brushes.Black, Preto);
                }

            }
        }

        private void CriarArquivo()
        {            
            StreamWriter Criar = new StreamWriter(@"C:\Users\2018101836\Desktop\Trab_Labirinto\Labirinto.txt");
            int Sorteio, i=0;
            Random Rd = new Random();

            string T="";
            while(i <= 2500) // (Comprimento) * (Altura);
            {                
                Sorteio = Rd.Next(0, 2); //0 == Branco | 1 == Preto
                T += Sorteio.ToString() + "";                
                i++;
                if (i % 50 == 0) //total / comprimento 
                {
                    Criar.WriteLine(T + "\n");
                    T = "";                    
                }                
            }
            Criar.Close();
        }

        private void LerArquivo()
        {

        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Parte1Labirinto();
            CriarArquivo();
        }
    }
}
