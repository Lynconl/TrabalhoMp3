﻿using MP3___Player.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP3___Player.Controller
{
    class List
    {
        private Node begin = null, end = null;

        internal Node Begin { get => begin; set => begin = value; }
        internal Node End { get => end; set => end = value; }

        //Deleta Músicas
        public void DeleteMusic()
        {
            if (Begin == null)
            {

                return;
            }
            if (Begin.Next == null)
            {
                Begin = null;
            }
            else
            {
                Node last = Begin.Next;
                Node penultimate = Begin;
                while (last.Next != null)
                {
                    penultimate = last;
                    last = last.Next;
                }
                penultimate.Next = null;
                end = penultimate;
            }
        }
        //Adiciona músicas
        public void InsertMusic(string Name, string Duraction, string Bitrate)
        {
            Node newNode = new Node(Name, Duraction, Bitrate);
            newNode.Name = Name;
            newNode.Duraction = Duraction;
            newNode.Bitrate = Bitrate;

            if (Begin == null)
            {
                Begin = newNode;
                End = newNode;
            }
            else
            {
                End.Next = newNode;
            }
            End = newNode;
        }
    }
}
