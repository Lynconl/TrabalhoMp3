﻿namespace MP3___Player
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelPlaylist = new System.Windows.Forms.Panel();
            this.txtBxCaminho = new System.Windows.Forms.TextBox();
            this.dataGridViewPlaylist = new System.Windows.Forms.DataGridView();
            this.Delete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictBxLight = new System.Windows.Forms.PictureBox();
            this.pictBxClose = new System.Windows.Forms.PictureBox();
            this.pictBxMaximize = new System.Windows.Forms.PictureBox();
            this.pictBxMinimize = new System.Windows.Forms.PictureBox();
            this.pictBxOpenFolder = new System.Windows.Forms.PictureBox();
            this.pictBxPrevious = new System.Windows.Forms.PictureBox();
            this.pictBxNext = new System.Windows.Forms.PictureBox();
            this.pictBxStop = new System.Windows.Forms.PictureBox();
            this.pictBxPlay = new System.Windows.Forms.PictureBox();
            this.pictBxRept = new System.Windows.Forms.PictureBox();
            this.pictBxReturn = new System.Windows.Forms.PictureBox();
            this.pictBxSound = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.bttnVolume = new System.Windows.Forms.Button();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.panelPlaylist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPlaylist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxLight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxMaximize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxOpenFolder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxPrevious)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxNext)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxPlay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxRept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxReturn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxSound)).BeginInit();
            this.SuspendLayout();
            // 
            // panelPlaylist
            // 
            this.panelPlaylist.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelPlaylist.BackColor = System.Drawing.Color.Transparent;
            this.panelPlaylist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelPlaylist.Controls.Add(this.txtBxCaminho);
            this.panelPlaylist.Controls.Add(this.dataGridViewPlaylist);
            this.panelPlaylist.Controls.Add(this.pictBxLight);
            this.panelPlaylist.Controls.Add(this.pictBxClose);
            this.panelPlaylist.Controls.Add(this.pictBxMaximize);
            this.panelPlaylist.Controls.Add(this.pictBxMinimize);
            this.panelPlaylist.Controls.Add(this.pictBxOpenFolder);
            this.panelPlaylist.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelPlaylist.Location = new System.Drawing.Point(534, 2);
            this.panelPlaylist.Name = "panelPlaylist";
            this.panelPlaylist.Size = new System.Drawing.Size(566, 594);
            this.panelPlaylist.TabIndex = 0;
            // 
            // txtBxCaminho
            // 
            this.txtBxCaminho.Location = new System.Drawing.Point(61, 8);
            this.txtBxCaminho.Multiline = true;
            this.txtBxCaminho.Name = "txtBxCaminho";
            this.txtBxCaminho.Size = new System.Drawing.Size(309, 48);
            this.txtBxCaminho.TabIndex = 93;
            // 
            // dataGridViewPlaylist
            // 
            this.dataGridViewPlaylist.AllowUserToAddRows = false;
            this.dataGridViewPlaylist.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridViewPlaylist.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewPlaylist.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridViewPlaylist.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dataGridViewPlaylist.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridViewPlaylist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPlaylist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewPlaylist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPlaylist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Delete,
            this.Nome,
            this.Column2,
            this.Column3});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPlaylist.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewPlaylist.EnableHeadersVisualStyles = false;
            this.dataGridViewPlaylist.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridViewPlaylist.Location = new System.Drawing.Point(-2, 63);
            this.dataGridViewPlaylist.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewPlaylist.Name = "dataGridViewPlaylist";
            this.dataGridViewPlaylist.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPlaylist.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewPlaylist.RowHeadersVisible = false;
            this.dataGridViewPlaylist.RowHeadersWidth = 20;
            this.dataGridViewPlaylist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Gray;
            this.dataGridViewPlaylist.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewPlaylist.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewPlaylist.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dataGridViewPlaylist.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewPlaylist.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.DarkGray;
            this.dataGridViewPlaylist.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.White;
            this.dataGridViewPlaylist.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewPlaylist.RowTemplate.DividerHeight = 1;
            this.dataGridViewPlaylist.RowTemplate.Height = 20;
            this.dataGridViewPlaylist.Size = new System.Drawing.Size(561, 529);
            this.dataGridViewPlaylist.TabIndex = 92;
            this.dataGridViewPlaylist.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dataGridViewPlaylist_KeyPress);
            // 
            // Delete
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.DefaultCellStyle = dataGridViewCellStyle3;
            this.Delete.HeaderText = "Del";
            this.Delete.MinimumWidth = 39;
            this.Delete.Name = "Delete";
            this.Delete.ReadOnly = true;
            this.Delete.Width = 39;
            // 
            // Nome
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.DimGray;
            this.Nome.DefaultCellStyle = dataGridViewCellStyle4;
            this.Nome.DividerWidth = 1;
            this.Nome.HeaderText = "Nome Música";
            this.Nome.MaxInputLength = 40;
            this.Nome.MinimumWidth = 318;
            this.Nome.Name = "Nome";
            this.Nome.ReadOnly = true;
            this.Nome.Width = 318;
            // 
            // Column2
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.DimGray;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column2.DividerWidth = 1;
            this.Column2.HeaderText = "Duração";
            this.Column2.MaxInputLength = 10;
            this.Column2.MinimumWidth = 100;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.DimGray;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column3.DividerWidth = 1;
            this.Column3.HeaderText = "BitRate";
            this.Column3.MaxInputLength = 10;
            this.Column3.MinimumWidth = 100;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // pictBxLight
            // 
            this.pictBxLight.Image = global::MP3___Player.Properties.Resources.contrast_48x48;
            this.pictBxLight.Location = new System.Drawing.Point(383, 3);
            this.pictBxLight.Name = "pictBxLight";
            this.pictBxLight.Size = new System.Drawing.Size(48, 48);
            this.pictBxLight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxLight.TabIndex = 13;
            this.pictBxLight.TabStop = false;
            this.pictBxLight.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxLight_MouseClick);
            // 
            // pictBxClose
            // 
            this.pictBxClose.Image = global::MP3___Player.Properties.Resources.power_48x48;
            this.pictBxClose.Location = new System.Drawing.Point(511, 3);
            this.pictBxClose.Name = "pictBxClose";
            this.pictBxClose.Size = new System.Drawing.Size(48, 48);
            this.pictBxClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxClose.TabIndex = 7;
            this.pictBxClose.TabStop = false;
            this.pictBxClose.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxClose_MouseClick);
            // 
            // pictBxMaximize
            // 
            this.pictBxMaximize.Image = global::MP3___Player.Properties.Resources.expand_48x48;
            this.pictBxMaximize.Location = new System.Drawing.Point(448, 3);
            this.pictBxMaximize.Name = "pictBxMaximize";
            this.pictBxMaximize.Size = new System.Drawing.Size(48, 48);
            this.pictBxMaximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxMaximize.TabIndex = 2;
            this.pictBxMaximize.TabStop = false;
            this.pictBxMaximize.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxMaximize_MouseClick);
            // 
            // pictBxMinimize
            // 
            this.pictBxMinimize.Image = global::MP3___Player.Properties.Resources.collapse_48x48;
            this.pictBxMinimize.Location = new System.Drawing.Point(448, 3);
            this.pictBxMinimize.Name = "pictBxMinimize";
            this.pictBxMinimize.Size = new System.Drawing.Size(48, 48);
            this.pictBxMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxMinimize.TabIndex = 1;
            this.pictBxMinimize.TabStop = false;
            this.pictBxMinimize.Visible = false;
            this.pictBxMinimize.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxMinimize_MouseClick);
            // 
            // pictBxOpenFolder
            // 
            this.pictBxOpenFolder.Image = global::MP3___Player.Properties.Resources.folder_48x48;
            this.pictBxOpenFolder.Location = new System.Drawing.Point(3, 8);
            this.pictBxOpenFolder.Name = "pictBxOpenFolder";
            this.pictBxOpenFolder.Size = new System.Drawing.Size(48, 48);
            this.pictBxOpenFolder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxOpenFolder.TabIndex = 0;
            this.pictBxOpenFolder.TabStop = false;
            this.pictBxOpenFolder.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxOpenFolder_MouseClick);
            // 
            // pictBxPrevious
            // 
            this.pictBxPrevious.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictBxPrevious.Image = global::MP3___Player.Properties.Resources.backward_48x48;
            this.pictBxPrevious.Location = new System.Drawing.Point(94, 540);
            this.pictBxPrevious.Name = "pictBxPrevious";
            this.pictBxPrevious.Size = new System.Drawing.Size(48, 48);
            this.pictBxPrevious.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxPrevious.TabIndex = 3;
            this.pictBxPrevious.TabStop = false;
            // 
            // pictBxNext
            // 
            this.pictBxNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictBxNext.Image = global::MP3___Player.Properties.Resources.fastforward_48x48;
            this.pictBxNext.Location = new System.Drawing.Point(243, 540);
            this.pictBxNext.Name = "pictBxNext";
            this.pictBxNext.Size = new System.Drawing.Size(48, 48);
            this.pictBxNext.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxNext.TabIndex = 4;
            this.pictBxNext.TabStop = false;
            // 
            // pictBxStop
            // 
            this.pictBxStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictBxStop.Image = global::MP3___Player.Properties.Resources.pause_48x48;
            this.pictBxStop.Location = new System.Drawing.Point(168, 540);
            this.pictBxStop.Name = "pictBxStop";
            this.pictBxStop.Size = new System.Drawing.Size(48, 48);
            this.pictBxStop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxStop.TabIndex = 5;
            this.pictBxStop.TabStop = false;
            this.pictBxStop.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxStop_MouseClick);
            // 
            // pictBxPlay
            // 
            this.pictBxPlay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictBxPlay.Image = global::MP3___Player.Properties.Resources.play_48x48;
            this.pictBxPlay.Location = new System.Drawing.Point(168, 540);
            this.pictBxPlay.Name = "pictBxPlay";
            this.pictBxPlay.Size = new System.Drawing.Size(48, 48);
            this.pictBxPlay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxPlay.TabIndex = 6;
            this.pictBxPlay.TabStop = false;
            this.pictBxPlay.Visible = false;
            this.pictBxPlay.Click += new System.EventHandler(this.pictBxPlay_Click);
            this.pictBxPlay.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxPlay_MouseClick);
            // 
            // pictBxRept
            // 
            this.pictBxRept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictBxRept.Image = global::MP3___Player.Properties.Resources.random_48x48;
            this.pictBxRept.Location = new System.Drawing.Point(12, 540);
            this.pictBxRept.Name = "pictBxRept";
            this.pictBxRept.Size = new System.Drawing.Size(48, 48);
            this.pictBxRept.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxRept.TabIndex = 8;
            this.pictBxRept.TabStop = false;
            // 
            // pictBxReturn
            // 
            this.pictBxReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictBxReturn.Image = global::MP3___Player.Properties.Resources.reload_48x48;
            this.pictBxReturn.Location = new System.Drawing.Point(330, 540);
            this.pictBxReturn.Name = "pictBxReturn";
            this.pictBxReturn.Size = new System.Drawing.Size(48, 48);
            this.pictBxReturn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxReturn.TabIndex = 9;
            this.pictBxReturn.TabStop = false;
            // 
            // pictBxSound
            // 
            this.pictBxSound.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictBxSound.Image = global::MP3___Player.Properties.Resources.sound_48x48;
            this.pictBxSound.Location = new System.Drawing.Point(402, 540);
            this.pictBxSound.Name = "pictBxSound";
            this.pictBxSound.Size = new System.Drawing.Size(48, 48);
            this.pictBxSound.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictBxSound.TabIndex = 10;
            this.pictBxSound.TabStop = false;
            this.pictBxSound.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictBxSound_MouseClick);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(515, 507);
            this.button1.TabIndex = 11;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // bttnVolume
            // 
            this.bttnVolume.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bttnVolume.BackColor = System.Drawing.Color.Green;
            this.bttnVolume.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttnVolume.Location = new System.Drawing.Point(456, 552);
            this.bttnVolume.Name = "bttnVolume";
            this.bttnVolume.Size = new System.Drawing.Size(7, 25);
            this.bttnVolume.TabIndex = 12;
            this.bttnVolume.UseVisualStyleBackColor = false;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1100, 600);
            this.Controls.Add(this.bttnVolume);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictBxSound);
            this.Controls.Add(this.pictBxReturn);
            this.Controls.Add(this.pictBxRept);
            this.Controls.Add(this.pictBxPlay);
            this.Controls.Add(this.pictBxStop);
            this.Controls.Add(this.pictBxNext);
            this.Controls.Add(this.pictBxPrevious);
            this.Controls.Add(this.panelPlaylist);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "PLAYER - MP3";
            this.panelPlaylist.ResumeLayout(false);
            this.panelPlaylist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPlaylist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxLight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxMaximize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxOpenFolder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxPrevious)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxNext)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxPlay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxRept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxReturn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBxSound)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelPlaylist;
        private System.Windows.Forms.PictureBox pictBxOpenFolder;
        private System.Windows.Forms.DataGridView dataGridViewPlaylist;
        private System.Windows.Forms.PictureBox pictBxLight;
        private System.Windows.Forms.PictureBox pictBxClose;
        private System.Windows.Forms.PictureBox pictBxMaximize;
        private System.Windows.Forms.PictureBox pictBxMinimize;
        private System.Windows.Forms.PictureBox pictBxPrevious;
        private System.Windows.Forms.PictureBox pictBxNext;
        private System.Windows.Forms.PictureBox pictBxStop;
        private System.Windows.Forms.PictureBox pictBxPlay;
        private System.Windows.Forms.PictureBox pictBxRept;
        private System.Windows.Forms.PictureBox pictBxReturn;
        private System.Windows.Forms.PictureBox pictBxSound;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button bttnVolume;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.TextBox txtBxCaminho;
    }
}

