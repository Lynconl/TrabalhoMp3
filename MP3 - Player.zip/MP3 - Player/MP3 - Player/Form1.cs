﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MP3___Player
{
    public partial class FormPrincipal : Form
    {
        int LightBackColor = 0;
        int TamPlaylist;

        public FormPrincipal()
        {
            InitializeComponent();                        
        }

        private void pictBxClose_MouseClick(object sender, MouseEventArgs e)
        {
            Close();
        }

        private void pictBxStop_MouseClick(object sender, MouseEventArgs e)
        {
            pictBxPlay.Visible = true; pictBxStop.Visible = false;
        }

        private void pictBxPlay_MouseClick(object sender, MouseEventArgs e)
        {
            pictBxPlay.Visible = false; pictBxStop.Visible = true;
        }

        private void pictBxLight_MouseClick(object sender, MouseEventArgs e)
        {
            if (LightBackColor == 0)
            {
                BackColor = Color.White;
                dataGridViewPlaylist.BackgroundColor = Color.White;
                LightBackColor = 1;
            }
            else
            {
                BackColor = Color.DarkGray;
                dataGridViewPlaylist.BackgroundColor = Color.DarkGray;
                LightBackColor = 0;
            }
            
        }

        private void pictBxMaximize_MouseClick(object sender, MouseEventArgs e)
        {
            pictBxMaximize.Visible = false; pictBxMinimize.Visible = true;
            
            Height = 700;
            Width = 1400;
        }

        private void pictBxMinimize_MouseClick(object sender, MouseEventArgs e)
        {
            pictBxMinimize.Visible = false; pictBxMaximize.Visible = true;
            Height = 600;
            Width = 1100;
        }

        private void pictBxSound_MouseClick(object sender, MouseEventArgs e)
        {
            bttnVolume.Width += 7;
            if(bttnVolume.Width > 70)
            {
                bttnVolume.Width = 0;
            }
        }

        private void dataGridViewPlaylist_KeyPress(object sender, KeyPressEventArgs e)
        {           
            if (e.KeyChar == 13)
            {
                DataGridViewRow Indice = dataGridViewPlaylist.CurrentRow;
                
                int linha = Indice.Index - 1;
                int coluna = dataGridViewPlaylist.GetCellCount(DataGridViewElementStates.Selected) - 1;
                
                
                if (dataGridViewPlaylist.SelectedCells[0].Displayed == true && coluna == 0)
                {                    
                    dataGridViewPlaylist.Rows.RemoveAt(linha);
                }
            }
        }

        private void pictBxOpenFolder_MouseClick(object sender, MouseEventArgs e)
        {
            FolderBrowserDialog Abrir = folderBrowserDialog;
            Abrir.ShowDialog();
            txtBxCaminho.Text = Abrir.SelectedPath;
            MessageBox.Show("Para excluir musicas de playlist, vá na coluna: DEL e aperte ENTER", "Aviso", MessageBoxButtons.OK);
            TamPlaylist = 24;

            for (int i = 0; i <= TamPlaylist; i++) //Montar a tabela
            {
                dataGridViewPlaylist.Rows.Add();
                dataGridViewPlaylist.Rows[i].Cells[0].Style.BackColor = Color.White;
                dataGridViewPlaylist.Rows[i].Cells[0].Value = "DEL";
                dataGridViewPlaylist.Rows[i].Cells[1].Style.BackColor = Color.White;
                dataGridViewPlaylist.Rows[i].Cells[2].Style.BackColor = Color.White;
                dataGridViewPlaylist.Rows[i].Cells[3].Style.BackColor = Color.White;
                if (i % 2 > 0 && i != 0)
                {
                    dataGridViewPlaylist.Rows[i].Cells[0].Value = "DEL";
                    dataGridViewPlaylist.Rows[i].Cells[0].Style.BackColor = Color.WhiteSmoke;
                    dataGridViewPlaylist.Rows[i].Cells[1].Style.BackColor = Color.WhiteSmoke;
                    dataGridViewPlaylist.Rows[i].Cells[2].Style.BackColor = Color.WhiteSmoke;
                    dataGridViewPlaylist.Rows[i].Cells[3].Style.BackColor = Color.WhiteSmoke;
                }
            }
        }
    }
}
